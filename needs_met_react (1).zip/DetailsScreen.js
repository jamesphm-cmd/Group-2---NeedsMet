import React from 'react';
import { useNavigate } from 'react-router-dom';

function DetailsScreen() {
  const navigate = useNavigate();

  return (
    <div style={{ padding: '16px' }}>
      <button onClick={() => navigate(-1)}>← Back</button>
      <h2>Request Details</h2>
      <p>Details about the selected request.</p>
    </div>
  );
}

export default DetailsScreen;