import React from 'react';
import { useNavigate } from 'react-router-dom';

const users = ['USER 1', 'USER 2', 'USER 3', 'USER 4'];

function HomeScreen() {
  const navigate = useNavigate();

  return (
    <div style={{ padding: '16px' }}>
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <button onClick={() => alert('Notifications clicked')}>🔔</button>
        <h2>AVAILABLE RQUESTS</h2>
        <div>
          <span>🔋 68%</span>
        </div>
      </header>

      {users.map((user, index) => (
        <div key={index} style={{ backgroundColor: '#ddd', padding: '12px', marginBottom: '16px', cursor: 'pointer' }} onClick={() => navigate('/details')}>
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <span style={{ marginRight: '8px' }}>👤</span>
            <strong>{user}</strong>
          </div>
          <div>RATINGS</div>
          <div>{'⭐'.repeat(0) + '☆'.repeat(5)}</div>
        </div>
      ))}
    </div>
  );
}

export default HomeScreen;